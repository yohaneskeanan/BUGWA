global.prefa = ['','!','.',',','🐤','🗿']
global.owner = ['6285166950708']
global.thumb = "https://files.catbox.moe/tdfgjo.jpg"
global.namabot = "build v1"
global.namaCreator = "zebuild is dev"
global.isLink = 'https://chat.whatsapp.com/qpydOqpshjQpjbv107wjal'